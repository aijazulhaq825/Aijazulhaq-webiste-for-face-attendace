# Face Recognition Attendance System
## Aijaz Model School & College, Sarai Naurang, Lakki Marwat
## Engine: OpenCV LBPH (NO TensorFlow, NO DeepFace, NO internet needed)

---

## WHY LBPH?
DeepFace/FaceNet requires TensorFlow + internet to download 90MB model weights,
and fails silently if GPU/lighting conditions don't match its training data.

OpenCV LBPH (Local Binary Pattern Histogram):
- Runs on any PC, even old ones
- Works in dim indoor lighting
- No internet required after pip install
- Trains in 2-5 seconds
- 100% offline

---

## SETUP (3 commands)

### Step 1 — Install dependencies
```bash
pip install flask opencv-python opencv-contrib-python numpy
```
Note: opencv-contrib-python is required (includes the face module with LBPH).

### Step 2 — Run
```bash
python app.py
```

### Step 3 — Open browser
```
http://127.0.0.1:5000
```

---

## HOW IT WORKS

### Registration
1. Student sits 40-70 cm from webcam
2. You capture 5-10 photos
3. OpenCV Haar Cascade detects face region in each photo
4. Each face crop is resized to 200x200 grayscale
5. LBPH model trains on all student face crops
6. Model saved to models/lbph_model.yml

### Recognition
1. New frame captured from webcam
2. Haar Cascade finds face region
3. LBPH predicts label + confidence score
4. Confidence < 85 = recognized → mark attendance
5. Confidence > 85 = unknown

### Confidence scores
| Score | Meaning |
|-------|---------|
| 0-40  | Excellent match |
| 40-65 | Good match |
| 65-85 | Weak match (still accepted) |
| >85   | Rejected as unknown |

---

## PROJECT STRUCTURE
```
face_attendance/
├── app.py                     ← Flask + LBPH engine
├── requirements.txt
├── dataset/
│   └── faces/
│       └── AMS-2025-001/     ← Raw + cropped photos per student
├── models/
│   ├── lbph_model.yml        ← Trained LBPH model
│   └── labels.json           ← Label → student ID mapping
├── attendance_logs/
│   └── 2025-09-01.csv
└── templates/
    ├── base.html
    ├── index.html
    ├── register.html          ← Live face detection debug panel
    ├── attendance.html
    └── dashboard.html
```

---

## DEPLOY ON SCHOOL LAN
```bash
# All students/teachers on same WiFi can access via browser:
# http://YOUR_PC_IP:5000
# (already configured in app.py with host="0.0.0.0")
```
