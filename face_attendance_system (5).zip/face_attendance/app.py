"""
Face Recognition Attendance System — ADVANCED EDITION
Aijaz Model School & College, Sarai Naurang, Lakki Marwat
Engine : OpenCV LBPH  (no TensorFlow, no internet)
FIX    : Every route wrapped in try/except → always returns JSON, never HTML error page
"""

import os, cv2, base64, csv, json, shutil, traceback, io
from flask import Flask, render_template, request, jsonify, send_file
from datetime import datetime, date
import numpy as np
from collections import defaultdict

app = Flask(__name__)
app.secret_key = "aijaz_school_2025_adv"

# ── Directories ──
FACES_DIR     = "dataset/faces"
LOG_DIR       = "attendance_logs"
MODEL_FILE    = "models/lbph_model.yml"
LABELS_FILE   = "models/labels.json"
STUDENTS_FILE = "models/students.json"
SETTINGS_FILE = "models/settings.json"
UPLOADS_DIR   = "static/uploads"

for _d in [FACES_DIR, LOG_DIR, "models", UPLOADS_DIR]:
    os.makedirs(_d, exist_ok=True)

# ── Global error handler: always JSON, never HTML ──
@app.errorhandler(Exception)
def handle_exception(e):
    tb = traceback.format_exc()
    print(f"[ERROR] Unhandled exception:\n{tb}")
    return jsonify({"success": False, "message": str(e), "traceback": tb[:600]}), 500

@app.errorhandler(404)
def handle_404(e):
    # Return HTML for page routes, JSON for /api/ routes
    if request.path.startswith("/api/"):
        return jsonify({"success": False, "message": "API endpoint not found."}), 404
    return render_template("404.html"), 404

# ════════════════════════════════════════
# IN-MEMORY STORES
# ════════════════════════════════════════
today_attendance = {}   # {student_id: {name,time,status,method}}
label_map        = {}   # {int_label: {"id":..,"name":..}}
id_to_label      = {}   # {student_id: int_label}
students_db      = {}   # {student_id: full profile dict}
settings         = {}

# ── LBPH recognizer ──
recognizer    = cv2.face.LBPHFaceRecognizer_create(
    radius=1, neighbors=8, grid_x=8, grid_y=8, threshold=100.0)
model_trained = False

# ── Haar cascades ──
frontal_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
profile_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_profileface.xml")

# ════════════════════════════════════════
# SETTINGS
# ════════════════════════════════════════
DEFAULT_SETTINGS = {
    "school_name": "Aijaz Model School & College",
    "school_location": "Sarai Naurang, Lakki Marwat",
    "admin_pin": "1234",
    "late_threshold": "08:30",
    "confidence_threshold": 85,
    "classes": ["Class 6","Class 7","Class 8","Class 9","Class 10","Class 11","Class 12"],
    "sections": ["A","B","C","D"]
}

def load_settings():
    global settings
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, encoding="utf-8") as f:
                settings = {**DEFAULT_SETTINGS, **json.load(f)}
        else:
            settings = DEFAULT_SETTINGS.copy()
            save_settings()
    except Exception as e:
        print(f"[WARN] load_settings error: {e} — using defaults")
        settings = DEFAULT_SETTINGS.copy()

def save_settings():
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)

# ════════════════════════════════════════
# FACE DETECTION
# ════════════════════════════════════════
def enhance_image(gray):
    clahe = cv2.createCLAHE(clipLimit=4.0, tileGridSize=(8, 8))
    eq = clahe.apply(gray)
    return cv2.GaussianBlur(eq, (3, 3), 0)

def detect_faces_gray(gray):
    found = []
    configs = [
        (frontal_cascade, 1.05, 4, (40, 40)),
        (frontal_cascade, 1.10, 3, (30, 30)),
        (frontal_cascade, 1.30, 2, (25, 25)),
        (profile_cascade, 1.05, 3, (40, 40)),
        (profile_cascade, 1.10, 2, (30, 30)),
    ]
    for cas, scale, neigh, minSz in configs:
        try:
            rects = cas.detectMultiScale(gray, scaleFactor=scale,
                minNeighbors=neigh, minSize=minSz, flags=cv2.CASCADE_SCALE_IMAGE)
            if len(rects) > 0:
                found.extend(rects.tolist())
        except Exception:
            pass
    # flipped profile
    try:
        flipped = cv2.flip(gray, 1)
        rects = profile_cascade.detectMultiScale(flipped, 1.1, 2, minSize=(30, 30))
        fw = gray.shape[1]
        for (x, y, w, h) in rects:
            found.append([fw - x - w, y, w, h])
    except Exception:
        pass
    if not found:
        return []
    found = sorted(found, key=lambda r: r[2] * r[3], reverse=True)
    keep = []
    for box in found:
        x1, y1, w1, h1 = box
        overlap = False
        for kx, ky, kw, kh in keep:
            ix = max(0, min(x1+w1, kx+kw) - max(x1, kx))
            iy = max(0, min(y1+h1, ky+kh) - max(y1, ky))
            if ix * iy > 0.4 * w1 * h1:
                overlap = True; break
        if not overlap:
            keep.append(box)
    return keep

def extract_face_roi(img_bgr):
    """Returns 200×200 grayscale ROI or None. Tries 5 image variants."""
    if img_bgr is None or img_bgr.size == 0:
        return None
    h, w = img_bgr.shape[:2]
    variants = [
        img_bgr,
        cv2.convertScaleAbs(img_bgr, alpha=1.8, beta=40),
        cv2.convertScaleAbs(img_bgr, alpha=2.5, beta=70),
    ]
    if w < 800:
        try:
            up = cv2.resize(img_bgr, (w * 2, h * 2))
            variants.append(up)
            variants.append(cv2.convertScaleAbs(up, alpha=1.8, beta=40))
        except Exception:
            pass
    for variant in variants:
        try:
            gray  = enhance_image(cv2.cvtColor(variant, cv2.COLOR_BGR2GRAY))
            faces = detect_faces_gray(gray)
            if faces:
                x, y, fw, fh = max(faces, key=lambda r: r[2] * r[3])
                pad = int(min(fw, fh) * 0.20)
                x1 = max(0, x - pad);       y1 = max(0, y - pad)
                x2 = min(gray.shape[1], x + fw + pad)
                y2 = min(gray.shape[0], y + fh + pad)
                roi = gray[y1:y2, x1:x2]
                if roi.size == 0:
                    continue
                return cv2.resize(roi, (200, 200))
        except Exception:
            continue
    return None

# ════════════════════════════════════════
# MODEL — load / save / retrain
# ════════════════════════════════════════
def load_model():
    global label_map, id_to_label, model_trained, students_db
    try:
        if os.path.exists(LABELS_FILE):
            with open(LABELS_FILE, encoding="utf-8") as f:
                raw = json.load(f)
            label_map   = {int(k): v for k, v in raw.items()}
            id_to_label = {v["id"]: int(k) for k, v in label_map.items()}
        if os.path.exists(MODEL_FILE) and label_map:
            recognizer.read(MODEL_FILE)
            model_trained = True
        if os.path.exists(STUDENTS_FILE):
            with open(STUDENTS_FILE, encoding="utf-8") as f:
                students_db = json.load(f)
        print(f"[INFO] Loaded {len(label_map)} students, model_trained={model_trained}")
    except Exception as e:
        print(f"[WARN] load_model error: {e}")

def save_model_files():
    """Save LBPH model + labels + students JSON. Safe — catches errors."""
    try:
        recognizer.write(MODEL_FILE)
        with open(LABELS_FILE, "w", encoding="utf-8") as f:
            json.dump({str(k): v for k, v in label_map.items()}, f)
        with open(STUDENTS_FILE, "w", encoding="utf-8") as f:
            json.dump(students_db, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[ERROR] save_model_files: {e}")

def retrain_model():
    """Rebuild LBPH from all saved face images. Returns (success, face_count)."""
    global model_trained
    faces, labels = [], []
    for sid, lbl in id_to_label.items():
        stu_dir = os.path.join(FACES_DIR, sid)
        if not os.path.isdir(stu_dir):
            continue
        for fname in os.listdir(stu_dir):
            if not fname.lower().endswith((".jpg", ".png", ".jpeg")):
                continue
            try:
                img = cv2.imread(os.path.join(stu_dir, fname))
                if img is None:
                    continue
                roi = extract_face_roi(img)
                if roi is not None:
                    faces.append(roi)
                    labels.append(lbl)
            except Exception as e:
                print(f"[WARN] retrain skip {fname}: {e}")
    if not faces:
        print("[WARN] retrain: zero usable face images found")
        return False, 0
    try:
        recognizer.train(faces, np.array(labels))
        save_model_files()
        model_trained = True
        print(f"[INFO] Retrained: {len(faces)} images, {len(id_to_label)} students")
        return True, len(faces)
    except Exception as e:
        print(f"[ERROR] recognizer.train: {e}")
        return False, 0

load_settings()
load_model()

# ════════════════════════════════════════
# ATTENDANCE HELPERS
# ════════════════════════════════════════
def safe_decode_image(data_url):
    """Decode base64 image. Returns (img_bgr, error_str)."""
    try:
        if not data_url or "," not in data_url:
            return None, "Empty or malformed image data"
        _, encoded = data_url.split(",", 1)
        arr = np.frombuffer(base64.b64decode(encoded), np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            return None, "cv2.imdecode returned None"
        return img, None
    except Exception as e:
        return None, str(e)

def is_late(time_str):
    try:
        threshold = datetime.strptime(settings.get("late_threshold", "08:30"), "%H:%M").time()
        actual    = datetime.strptime(time_str, "%H:%M:%S").time()
        return actual > threshold
    except Exception:
        return False

def log_attendance(student_id, name, method="face", confidence=None, status=None):
    today_str = str(date.today())
    log_file  = os.path.join(LOG_DIR, f"{today_str}.csv")
    exists    = os.path.exists(log_file)
    now       = datetime.now().strftime("%H:%M:%S")
    if status is None:
        status = "Late" if is_late(now) else "Present"
    stu = students_db.get(student_id, {})
    cls = str(stu.get("class", ""))
    sec = str(stu.get("section", ""))
    conf_str = f"{confidence:.1f}" if confidence is not None else ""
    with open(log_file, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if not exists:
            w.writerow(["Student ID","Name","Class","Section","Date","Time","Status","Method","Confidence"])
        w.writerow([student_id, name, cls, sec, today_str, now, status, method, conf_str])
    today_attendance[student_id] = {
        "name": name, "time": now, "status": status,
        "method": method, "class": cls, "section": sec
    }
    return now, status

def read_log(log_date):
    log_file = os.path.join(LOG_DIR, f"{log_date}.csv")
    if not os.path.exists(log_file):
        return []
    try:
        with open(log_file, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))
    except Exception as e:
        print(f"[WARN] read_log {log_date}: {e}")
        return []

def get_attendance_stats(log_date):
    records  = read_log(log_date)
    present  = [r for r in records if r.get("Status") in ("Present", "Late")]
    late     = [r for r in records if r.get("Status") == "Late"]
    marked_ids = {r["Student ID"] for r in records}
    absent_ids = set(students_db.keys()) - marked_ids
    return {
        "total_registered": len(students_db),
        "present": len(present),
        "late": len(late),
        "absent": len(absent_ids),
        "records": [dict(r) for r in records],
        "absent_students": [
            {"student_id": sid, "name": students_db[sid].get("name",""),
             "class": students_db[sid].get("class",""),
             "section": students_db[sid].get("section","")}
            for sid in absent_ids if sid in students_db
        ]
    }

def monthly_summary(year, month):
    from calendar import monthrange
    _, days = monthrange(year, month)
    summary = {}
    for sid, info in students_db.items():
        summary[sid] = {
            "name": info.get("name",""), "class": info.get("class",""),
            "section": info.get("section",""),
            "present": 0, "late": 0, "absent": 0, "total_days": 0
        }
    for day in range(1, days + 1):
        d = date(year, month, day)
        if d > date.today():
            continue
        records = read_log(str(d))
        if not records:
            continue
        day_map = {r["Student ID"]: r.get("Status","") for r in records}
        for sid in students_db:
            summary[sid]["total_days"] += 1
            s = day_map.get(sid, "")
            if s == "Present":   summary[sid]["present"] += 1
            elif s == "Late":    summary[sid]["late"]    += 1
            else:                summary[sid]["absent"]  += 1
    return summary

# ════════════════════════════════════════
# PAGE ROUTES
# ════════════════════════════════════════
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register")
def register():
    return render_template("register.html")

@app.route("/attendance")
def attendance():
    return render_template("attendance.html")

@app.route("/students")
def students_page():
    return render_template("students.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.route("/reports")
def reports():
    return render_template("reports.html")

@app.route("/settings")
def settings_page():
    return render_template("settings_page.html")

# ════════════════════════════════════════
# API ROUTES  — every one has try/except
# ════════════════════════════════════════

# ── Settings ──
@app.route("/api/settings", methods=["GET"])
def api_get_settings():
    try:
        return jsonify(settings)
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route("/api/settings", methods=["POST"])
def api_save_settings():
    try:
        body = request.get_json(force=True, silent=True) or {}
        settings.update(body)
        save_settings()
        return jsonify({"success": True, "message": "Settings saved."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# ── Register student ──
@app.route("/api/register", methods=["POST"])
def api_register():
    try:
        body       = request.get_json(force=True, silent=True) or {}
        student_id = str(body.get("student_id", "")).strip()
        name       = str(body.get("name", "")).strip()
        images     = body.get("images", [])

        if not student_id or not name:
            return jsonify({"success": False, "message": "Student ID and Name are required."})
        if not images:
            return jsonify({"success": False, "message": "Capture at least 1 photo."})

        # Assign label
        if student_id not in id_to_label:
            new_lbl = max(label_map.keys(), default=-1) + 1
            label_map[new_lbl]    = {"id": student_id, "name": name}
            id_to_label[student_id] = new_lbl

        # Save/update rich profile
        students_db[student_id] = {
            "name":    name,
            "class":   str(body.get("class",   "")),
            "section": str(body.get("section", "")),
            "roll":    str(body.get("roll",    "")),
            "gender":  str(body.get("gender",  "")),
            "dob":     str(body.get("dob",     "")),
            "phone":   str(body.get("phone",   "")),
            "registered_at": str(datetime.now()),
            "photo":   students_db.get(student_id, {}).get("photo", "")
        }

        student_dir = os.path.join(FACES_DIR, student_id)
        os.makedirs(student_dir, exist_ok=True)

        saved      = 0
        face_found = 0
        debug_log  = []
        best_face  = None

        for i, img_url in enumerate(images[:20]):
            try:
                img, err = safe_decode_image(img_url)
                if img is None:
                    debug_log.append(f"img{i}:decode_fail({err})")
                    continue
                cv2.imwrite(os.path.join(student_dir, f"{i}_raw.jpg"), img)
                saved += 1
                roi = extract_face_roi(img)
                if roi is not None:
                    cv2.imwrite(os.path.join(student_dir, f"{i}_face.jpg"), roi)
                    face_found += 1
                    debug_log.append(f"img{i}:ok")
                    if best_face is None:
                        best_face = img
                else:
                    debug_log.append(f"img{i}:no_face")
            except Exception as ex:
                debug_log.append(f"img{i}:err={ex}")

        # Save profile thumbnail
        if best_face is not None:
            try:
                h, w = best_face.shape[:2]
                sz = min(h, w, 300)
                cy, cx = h // 2, w // 2
                crop = best_face[max(0, cy-sz//2):cy+sz//2, max(0, cx-sz//2):cx+sz//2]
                if crop.size > 0:
                    thumb_path = os.path.join(UPLOADS_DIR, f"{student_id}.jpg")
                    cv2.imwrite(thumb_path, cv2.resize(crop, (150, 150)))
                    students_db[student_id]["photo"] = f"/static/uploads/{student_id}.jpg"
            except Exception as ex:
                print(f"[WARN] thumbnail save: {ex}")

        ok, fc = retrain_model()

        if not ok and face_found == 0:
            return jsonify({
                "success": False,
                "message": (f"Saved {saved} photos but no face detected in any. "
                            f"Debug: {', '.join(debug_log[:4])}. "
                            "Sit 40–70 cm from camera, face forward, add front lighting.")
            })

        quality = "⭐⭐⭐ Excellent" if face_found >= 7 else "⭐⭐ Good" if face_found >= 3 else "⭐ Basic"
        return jsonify({
            "success": True,
            "message": f"✅ {name} registered! {face_found}/{saved} photos with face ({quality})."
        })

    except Exception as e:
        tb = traceback.format_exc()
        print(f"[ERROR] /api/register:\n{tb}")
        return jsonify({"success": False, "message": f"Server error: {e}"}), 500

# ── Recognize & mark attendance ──
@app.route("/api/recognize", methods=["POST"])
def api_recognize():
    try:
        body    = request.get_json(force=True, silent=True) or {}
        img_url = body.get("image", "")

        if not img_url:
            return jsonify({"success": False, "message": "No image data received."})

        img, err = safe_decode_image(img_url)
        if img is None:
            return jsonify({"success": False, "message": f"Image decode failed: {err}"})

        if not label_map:
            return jsonify({"success": False, "message": "No students registered yet."})
        if not model_trained:
            return jsonify({"success": False, "message": "Model not trained. Register students first."})

        roi = extract_face_roi(img)
        if roi is None:
            return jsonify({"success": False, "message": "No face detected. Move closer or improve lighting."})

        lbl, confidence = recognizer.predict(roi)
        confidence = float(confidence)
        THRESHOLD  = float(settings.get("confidence_threshold", 85))

        if confidence > THRESHOLD or lbl not in label_map:
            return jsonify({
                "success": False, "name": "Unknown",
                "confidence": round(confidence, 1),
                "message": f"Face not recognized (conf={confidence:.1f}, threshold={THRESHOLD})."
            })

        info       = label_map[lbl]
        student_id = info["id"]
        name       = info["name"]
        already    = student_id in today_attendance

        if not already:
            now, status = log_attendance(student_id, name, method="face", confidence=confidence)
        else:
            now    = today_attendance[student_id]["time"]
            status = today_attendance[student_id]["status"]

        stu = students_db.get(student_id, {})
        return jsonify({
            "success": True, "student_id": student_id, "name": name,
            "class": stu.get("class", ""), "section": stu.get("section", ""),
            "photo": stu.get("photo", ""),
            "confidence": round(confidence, 1),
            "already_marked": already, "time": now, "status": status,
            "message": f"{'Already marked' if already else 'Attendance marked'} for {name}"
        })

    except Exception as e:
        tb = traceback.format_exc()
        print(f"[ERROR] /api/recognize:\n{tb}")
        return jsonify({"success": False, "message": f"Server error: {e}"}), 500

# ── Manual attendance override ──
@app.route("/api/manual_attendance", methods=["POST"])
def api_manual_attendance():
    try:
        body       = request.get_json(force=True, silent=True) or {}
        student_id = str(body.get("student_id", "")).strip()
        status     = str(body.get("status", "Present"))
        log_date   = str(body.get("date", str(date.today())))
        pin        = str(body.get("pin", ""))

        if pin != str(settings.get("admin_pin", "1234")):
            return jsonify({"success": False, "message": "Wrong admin PIN."})
        if student_id not in students_db:
            return jsonify({"success": False, "message": "Student not found."})

        name = students_db[student_id]["name"]

        if log_date == str(date.today()):
            if status == "Absent":
                today_attendance.pop(student_id, None)
            log_attendance(student_id, name, method="manual", status=status)
            if status == "Absent":
                today_attendance.pop(student_id, None)
        else:
            log_file = os.path.join(LOG_DIR, f"{log_date}.csv")
            exists   = os.path.exists(log_file)
            stu      = students_db.get(student_id, {})
            with open(log_file, "a", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                if not exists:
                    w.writerow(["Student ID","Name","Class","Section","Date","Time","Status","Method","Confidence"])
                w.writerow([student_id, name,
                            stu.get("class",""), stu.get("section",""),
                            log_date, "00:00:00", status, "manual", ""])
        return jsonify({"success": True, "message": f"{name} marked {status} for {log_date}."})

    except Exception as e:
        return jsonify({"success": False, "message": f"Server error: {e}"}), 500

# ── Today's attendance ──
@app.route("/api/today")
def api_today():
    try:
        records = [{"student_id": sid, **info} for sid, info in today_attendance.items()]
        return jsonify({"date": str(date.today()), "total": len(records), "records": records})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# ── Stats for a date ──
@app.route("/api/stats/<log_date>")
def api_stats(log_date):
    try:
        return jsonify(get_attendance_stats(log_date))
    except Exception as e:
        return jsonify({"success": False, "message": str(e),
                        "total_registered": 0, "present": 0, "late": 0,
                        "absent": 0, "records": [], "absent_students": []}), 500

# ── Monthly report ──
@app.route("/api/monthly/<int:year>/<int:month>")
def api_monthly(year, month):
    try:
        data = monthly_summary(year, month)
        return jsonify({"year": year, "month": month, "students": list(data.values())})
    except Exception as e:
        return jsonify({"success": False, "message": str(e), "students": []}), 500

# ── Download daily CSV ──
@app.route("/api/download/<log_date>")
def api_download(log_date):
    try:
        log_file = os.path.join(LOG_DIR, f"{log_date}.csv")
        if not os.path.exists(log_file):
            return jsonify({"error": f"No log for {log_date}."}), 404
        return send_file(log_file, as_attachment=True,
                         download_name=f"attendance_{log_date}.csv")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Download monthly CSV ──
@app.route("/api/download_monthly/<int:year>/<int:month>")
def api_download_monthly(year, month):
    try:
        data = monthly_summary(year, month)
        si   = io.StringIO()
        w    = csv.writer(si)
        w.writerow(["Student ID","Name","Class","Section","Present","Late","Absent","Total Days","Attendance %"])
        for sid, row in data.items():
            total = row["total_days"] or 1
            pct   = round((row["present"] + row["late"]) / total * 100, 1)
            w.writerow([sid, row["name"], row["class"], row["section"],
                        row["present"], row["late"], row["absent"], row["total_days"], pct])
        si.seek(0)
        bio = io.BytesIO(si.getvalue().encode("utf-8"))
        return send_file(bio, as_attachment=True, mimetype="text/csv",
                         download_name=f"monthly_{year}_{month:02d}.csv")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── All log dates ──
@app.route("/api/logs")
def api_logs():
    try:
        files = sorted(
            [f.replace(".csv", "") for f in os.listdir(LOG_DIR) if f.endswith(".csv")],
            reverse=True)
        return jsonify({"dates": files})
    except Exception as e:
        return jsonify({"dates": [], "error": str(e)})

# ── Students list ──
@app.route("/api/students")
def api_students():
    try:
        rows = [{"student_id": sid, **info, "label": id_to_label.get(sid, -1)}
                for sid, info in students_db.items()]
        return jsonify({"total": len(rows), "students": rows})
    except Exception as e:
        return jsonify({"total": 0, "students": [], "error": str(e)}), 500

# ── Single student profile ──
@app.route("/api/student/<student_id>", methods=["GET"])
def api_get_student(student_id):
    try:
        if student_id not in students_db:
            return jsonify({"success": False, "message": "Student not found."}), 404
        return jsonify({"success": True,
                        "student": {"student_id": student_id, **students_db[student_id]}})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# ── Delete student ──
@app.route("/api/student/<student_id>", methods=["DELETE"])
def api_delete_student(student_id):
    try:
        if student_id not in id_to_label:
            return jsonify({"success": False, "message": "Student not found."}), 404
        lbl = id_to_label.pop(student_id)
        label_map.pop(lbl, None)
        students_db.pop(student_id, None)
        sdir = os.path.join(FACES_DIR, student_id)
        if os.path.exists(sdir):
            shutil.rmtree(sdir)
        photo = os.path.join(UPLOADS_DIR, f"{student_id}.jpg")
        if os.path.exists(photo):
            os.remove(photo)
        retrain_model()
        return jsonify({"success": True, "message": "Student deleted and model retrained."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# ── Student attendance history ──
@app.route("/api/student_history/<student_id>")
def api_student_history(student_id):
    try:
        history = []
        for fname in sorted(os.listdir(LOG_DIR)):
            if not fname.endswith(".csv"):
                continue
            for row in read_log(fname.replace(".csv", "")):
                if row.get("Student ID") == student_id:
                    history.append(dict(row))
        return jsonify({"student_id": student_id, "history": history})
    except Exception as e:
        return jsonify({"student_id": student_id, "history": [], "error": str(e)}), 500

# ── Debug detect ──
@app.route("/api/debug_detect", methods=["POST"])
def api_debug():
    try:
        body    = request.get_json(force=True, silent=True) or {}
        img_url = body.get("image", "")
        img, err = safe_decode_image(img_url)
        if img is None:
            return jsonify({"faces_found": 0, "roi_extracted": False,
                            "mean_brightness": 0, "brightness_label": "error",
                            "rects": [], "error": err})
        gray  = enhance_image(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
        faces = detect_faces_gray(gray)
        mb    = float(np.mean(gray))
        roi   = extract_face_roi(img)
        return jsonify({
            "faces_found":     len(faces),
            "mean_brightness": round(mb, 1),
            "brightness_label": ("dark" if mb < 70 else "low" if mb < 110
                                  else "ok" if mb < 200 else "bright"),
            "roi_extracted":   roi is not None,
            "rects":           [list(map(int, f)) for f in faces[:5]]
        })
    except Exception as e:
        return jsonify({"faces_found": 0, "roi_extracted": False,
                        "mean_brightness": 0, "brightness_label": "error",
                        "rects": [], "error": str(e)}), 500

# ════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 55)
    print("  Face Attendance ADVANCED — LBPH Engine")
    print("  Aijaz Model School & College")
    print("  http://127.0.0.1:5000")
    print("=" * 55)
    app.run(debug=True, host="0.0.0.0", port=5000)
